// ============================================
// SessionMaster · 会话大师 - Background Service Worker
// © 2026 BenSon.Album (chinasir@qq.com)
// 仅供学习研究，请遵守相关服务条款
// ============================================

import { APP_CONFIG } from './config.js';
const { DEFAULT_PORT, STORAGE_KEYS, UPDATE, SYNC_DEFAULTS, SERVER_SYNC_DEFAULTS, HEARTBEAT_DEFAULTS, GITHUB, LOCAL_DISCOVERY, TIMEOUT } = APP_CONFIG;

// ========== 存储函数 ==========

async function getStorage(key, defaultVal = null) {
  const result = await chrome.storage.local.get(key);
  return result[key] !== undefined ? result[key] : defaultVal;
}

async function setStorage(key, value) {
  await chrome.storage.local.set({ [key]: value });
}

// ========== 日志系统 ==========
// 以文件形式记录关键操作，支持导出为文本
// 自动清理规则：文件总大小超限后删除最旧记录

const LOG_KEY = 'app_logs';
const LOG_SIZE_KEY = 'app_logs_size';
const MAX_LOG_SIZE = 10 * 1024 * 1024; // 日志上限 10MB（需 unlimitedStorage 权限）

async function getLogs() {
  const logs = await getStorage(LOG_KEY, []);
  return Array.isArray(logs) ? logs : [];
}

async function addLog(level, module, message, data) {
  let logs = await getLogs();
  const entry = { time: new Date().toISOString(), level, module, message, data: data || null };
  
  // 估算单条体积（JSON 序列化长度 + 存储开销）
  const entrySize = JSON.stringify(entry).length + 50;
  let totalSize = (await getStorage(LOG_SIZE_KEY, 0)) + entrySize;
  
  logs.push(entry);
  
  // 超出上限时删除最旧的记录，直到低于阈值（留 20% 余量）
  while (totalSize > MAX_LOG_SIZE * 0.8 && logs.length > 1) {
    const removed = logs.shift();
    totalSize -= JSON.stringify(removed).length + 50;
    if (totalSize < 0) totalSize = 0;
  }
  
  await setStorage(LOG_KEY, logs);
  await setStorage(LOG_SIZE_KEY, Math.round(totalSize));
  
  // 同时输出到控制台方便调试
  console.log(`[SessionMaster] [${level}] [${module}] ${message}`, data || '');
}

async function clearLogs() {
  await setStorage(LOG_KEY, []);
  await setStorage(LOG_SIZE_KEY, 0);
  console.log('[SessionMaster] [INFO] [general] 日志已清空');
}

async function exportLogs() {
  const logs = await getLogs();
  const size = await getStorage(LOG_SIZE_KEY, 0);
  const sizeStr = size > 1024 * 1024 ? (size / 1024 / 1024).toFixed(1) + ' MB' :
                  size > 1024 ? Math.round(size / 1024) + ' KB' : size + ' B';

  // 收集所有信息
  const identity = await getDeviceIdentity();
  const deviceName = await getDeviceDisplayName();
  const details = await collectDeviceDetails();
  const netIfaces = await collectNetworkInfo();

  const now = new Date().toLocaleString();
  const sepBar = '============================\n';
  const sepDash = '----------------------------\n';

  let sections = [];

  // === 标题 ===
  sections.push(
    'SessionMaster 会话大师 - 操作日志\n' +
    '生成时间: ' + now + '\n' +
    sepBar
  );

  // === 📱 设备信息 ===
  let devBlock = '📱 设备信息\n' + sepDash;
  if (deviceName) devBlock += '设备名称: ' + deviceName + '\n';
  devBlock += '设备 ID: ' + identity.id + '\n';
  if (identity.createdAt) devBlock += '身份创建: ' + new Date(identity.createdAt).toLocaleString() + '\n';
  devBlock += '\n';
  sections.push(devBlock);

  // === 💻 系统信息 ===
  let sysBlock = '💻 系统信息\n' + sepDash;
  sysBlock += '操作系统: ' + details.os + (details.arch ? ' (' + details.arch + ')' : '') + '\n';
  if (details.platform) sysBlock += '平台: ' + details.platform + '\n';
  if (details.language) sysBlock += '语言: ' + details.language + '\n';
  if (details.cpuCores) sysBlock += 'CPU 核心: ' + details.cpuCores + '\n';
  if (details.deviceMemory) sysBlock += '内存: ' + details.deviceMemory + ' GB\n';
  sysBlock += '\n';
  sections.push(sysBlock);

  // === 🌐 浏览器信息 ===
  let browserBlock = '🌐 浏览器信息\n' + sepDash;
  browserBlock += '浏览器: ' + details.browser + (details.browserVer ? ' ' + details.browserVer : '') + '\n';
  if (details.uaShort) browserBlock += 'User-Agent: ' + details.uaShort + '\n';
  browserBlock += '\n';
  sections.push(browserBlock);

  // === 🌍 网络信息 ===
  if (netIfaces.length > 0) {
    let netBlock = '🌍 网络信息（非回环接口）\n' + sepDash;
    for (const iface of netIfaces) {
      netBlock += '  ' + iface.name + ': ' + iface.addr + iface.prefix + '\n';
    }
    netBlock += '\n';
    sections.push(netBlock);
  }

  // === 📊 日志统计 ===
  let statBlock = '📊 日志统计\n' + sepDash;
  statBlock += '共 ' + logs.length + ' 条记录, 约 ' + sizeStr + '\n';
  statBlock += '日志上限: ' + (MAX_LOG_SIZE / 1024 / 1024) + ' MB\n';
  statBlock += '\n';
  sections.push(statBlock);

  // === 日志内容 ===
  sections.push(sepBar + '\n');
  sections.push(logs.map(function(l) {
    return '[' + new Date(l.time).toLocaleString() + '] [' + l.level + '] [' + l.module + '] ' + l.message;
  }).join('\n'));

  sections.push('\n\n' + sepBar);
  sections.push('--- 日志结束 ---');

  return sections.join('');
}

const logger = {
  info: function(m, msg, d) { return addLog('INFO', m, msg, d); },
  warn: function(m, msg, d) { return addLog('WARN', m, msg, d); },
  error: function(m, msg, d) { return addLog('ERROR', m, msg, d); },
  debug: function(m, msg, d) { return addLog('DEBUG', m, msg, d); },
  clear: clearLogs,
  export: exportLogs,
  getAll: getLogs
};

// ========== 设备身份标识 ==========
// 固定存储：唯一设备 ID（仅生成一次）
// 动态信息（浏览器/系统/网络等）在导出日志时实时收集

const DEVICE_IDENTITY_KEY = 'device_identity';

async function getDeviceIdentity() {
  let identity = await getStorage(DEVICE_IDENTITY_KEY, null);
  if (!identity) {
    const id = 'dev-' + Date.now().toString(36) + '-' + Math.random().toString(36).substring(2, 8);
    identity = { id, createdAt: new Date().toISOString() };
    await setStorage(DEVICE_IDENTITY_KEY, identity);
    console.log('[SessionMaster] [INFO] [general] 设备身份已创建: ' + id);
  }
  return identity;
}

// 重置设备 ID（手动操作）
async function resetDeviceIdentity() {
  const old = await getStorage(DEVICE_IDENTITY_KEY, null);
  const newId = 'dev-' + Date.now().toString(36) + '-' + Math.random().toString(36).substring(2, 8);
  const identity = { id: newId, createdAt: new Date().toISOString(), previousId: old ? old.id : null };
  await setStorage(DEVICE_IDENTITY_KEY, identity);
  return identity;
}

// 获取用户自定义设备名（从同步配置）
async function getDeviceDisplayName() {
  const p2pCfg = await getSyncConfig();
  const srvCfg = await serverGetSyncConfig();
  return p2pCfg.p2pDeviceName || srvCfg.deviceName || '';
}

// 实时收集当前设备详情（OS、浏览器、语言等）
async function collectDeviceDetails() {
  const platform = await new Promise(resolve => {
    try { chrome.runtime.getPlatformInfo(info => resolve(info || null)); } catch { resolve(null); }
  });
  const nav = typeof navigator !== 'undefined' ? navigator : null;
  const ua = nav ? nav.userAgent || '' : '';
  // 解析浏览器名称/版本
  let browserName = '未知';
  let browserVer = '';
  if (ua.includes('Chrome/') && !ua.includes('Edg/')) {
    const m = ua.match(/Chrome\/([\d.]+)/);
    browserName = 'Chrome';
    browserVer = m ? m[1] : '';
  } else if (ua.includes('Edg/')) {
    const m = ua.match(/Edg\/([\d.]+)/);
    browserName = 'Edge';
    browserVer = m ? m[1] : '';
  } else if (ua.includes('Firefox/')) {
    const m = ua.match(/Firefox\/([\d.]+)/);
    browserName = 'Firefox';
    browserVer = m ? m[1] : '';
  } else if (ua.includes('Safari/') && !ua.includes('Chrome/')) {
    const m = ua.match(/Version\/([\d.]+)/);
    browserName = 'Safari';
    browserVer = m ? m[1] : '';
  }
  const osMap = { mac: 'macOS', win: 'Windows', android: 'Android', cros: 'ChromeOS', linux: 'Linux', openbsd: 'OpenBSD' };
  return {
    os: platform ? (osMap[platform.os] || platform.os) : '未知',
    arch: platform ? platform.arch : '',
    browser: browserName,
    browserVer: browserVer,
    language: nav ? nav.language || '' : '',
    platform: nav ? nav.platform || '' : '',
    cpuCores: nav ? nav.hardwareConcurrency || '' : '',
    deviceMemory: nav ? nav.deviceMemory || '' : '',
    uaShort: ua.substring(0, 150)
  };
}

// 实时收集网络接口信息
async function collectNetworkInfo() {
  try {
    if (typeof chrome.system !== 'undefined' && chrome.system.network &&
        typeof chrome.system.network.getNetworkInterfaces === 'function') {
      const ifaces = await chrome.system.network.getNetworkInterfaces();
      if (ifaces && ifaces.length > 0) {
        // 只显示非回环 IPv4 地址
        const entries = ifaces
          .filter(i => i && i.address && !i.address.startsWith('127.') && !i.address.startsWith('::1'))
          .map(i => {
            const name = i.name || '未知';
            const addr = i.address || '';
            const prefix = i.prefixLength !== undefined ? '/' + i.prefixLength : '';
            return { name, addr, prefix };
          });
        return entries;
      }
    }
  } catch (e) {
    // 静默失败
  }
  return [];
}

// ========== 图标状态角标（动态动画）==========
// 空闲: 无角标
// 保活中: ♡♥ 跳动（绿色 #34a853）
// 同步中: ◴◷◶◵ 旋转（蓝色 #1a73e8）
// 两者  : ◴◷◶◵ 旋转（紫色 #7b1fa2）

let iconAnimTimer = null;

function stopIconAnimation() {
  if (iconAnimTimer) {
    clearInterval(iconAnimTimer);
    iconAnimTimer = null;
  }
}

function startIconAnimation(frames, intervalMs, bgColor) {
  stopIconAnimation();
  let i = 0;
  chrome.action.setBadgeBackgroundColor({ color: bgColor }).catch(() => {});
  chrome.action.setBadgeText({ text: frames[0] }).catch(() => {});
  iconAnimTimer = setInterval(() => {
    i = (i + 1) % frames.length;
    chrome.action.setBadgeText({ text: frames[i] }).catch(() => {});
  }, intervalMs);
}

async function updateIconState() {
  stopIconAnimation();
  const beats = await getHeartbeats();
  const config = await getSyncConfig();
  const serverConfig = await serverGetSyncConfig();
  const hasHeartbeat = beats.some(b => b.enabled);
  const hasSync = (config.enabled && config.mode === 'p2p') || serverConfig.enabled;

  if (hasHeartbeat && hasSync) {
    // 紫色旋转 — 两者都在运行
    startIconAnimation(['◴', '◷', '◶', '◵'], 250, '#7b1fa2');
  } else if (hasHeartbeat) {
    // 绿色心跳 — 保活中
    startIconAnimation(['♥', '♡', '♥', '♡', '♥', '♡', '♥', '♡', '♥', '♡'], 400, '#34a853');
  } else if (hasSync) {
    // 蓝色旋转 — 同步中
    startIconAnimation(['◴', '◷', '◶', '◵'], 250, '#1a73e8');
  } else {
    // 空闲: 无角标
    await chrome.action.setBadgeText({ text: '' });
  }
}

// ========== Cookie 管理 ==========

async function getCookies(domain) {
  let results = [];
  const formats = [];
  
  function addFormat(d) {
    if (!d || d.length < 2 || d.includes(' ')) return;
    if (!formats.includes(d)) formats.push(d);
    if (!d.startsWith('.')) {
      const dotted = '.' + d;
      if (!formats.includes(dotted)) formats.push(dotted);
    }
  }

  // 1. 总是先查原始域名（如 localhost、IP、裸域）
  if (domain) addFormat(domain);

  // 2. 对多段域名，逐级向上查父级域
  //    music.163.com → 查 .music.163.com → 163.com → .163.com
  //    www.example.co.uk → 查 example.co.uk
  //    IP 地址（192.168.1.1）跳过父级查询
  const cleanDomain = (domain || '').replace(/^\./, '').toLowerCase().split(':')[0];
  if (!/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(cleanDomain)) {
    const parts = cleanDomain.split('.');
    if (parts.length >= 2) {
      for (let i = parts.length - 1; i >= 2; i--) {
        addFormat(parts.slice(parts.length - i).join('.'));
      }
    }
  }
  
  for (const d of formats) {
    try { results = results.concat(await chrome.cookies.getAll({ domain: d })); } catch (e) {}
  }
  const seen = new Set();
  return results.filter(c => { const key = `${c.name}:${c.domain}:${c.path}`; if (seen.has(key)) return false; seen.add(key); return true; });
}

async function exportCookies(domain) {
  const cookies = await getCookies(domain);
  if (cookies.length === 0) {
    logger.warn('cookie', '导出 Cookie 为空: ' + domain);
    return { success: false, message: '未找到该域名的 Cookie', data: null };
  }
  const exportTime = new Date().toISOString();
  const data = { domain, exportTime, cookies: cookies.map(c => ({ name: c.name, value: c.value, domain: c.domain, path: c.path, secure: c.secure, httpOnly: c.httpOnly, sameSite: c.sameSite, hostOnly: c.hostOnly, _exportTime: exportTime })), quick: cookies.map(c => `${c.name}=${c.value}`).join('; ') };
  logger.info('cookie', '导出 Cookie: ' + domain + ', ' + cookies.length + ' 个');
  return { success: true, message: `已导出 ${cookies.length} 个 Cookie`, data };
}

async function importCookies(cookieData) {
  const results = { success: 0, failed: 0, errors: [] };
  for (const c of cookieData.cookies) {
    try {
      const details = { url: `${c.secure ? 'https' : 'http'}://${c.domain}${c.path}`, name: c.name, value: c.value, path: c.path || '/', secure: c.secure !== false, httpOnly: c.httpOnly === true, sameSite: c.sameSite || 'lax' };
      if (!c.hostOnly) details.domain = c.domain;
      await chrome.cookies.set(details);
      results.success++;
    } catch (e) { results.failed++; results.errors.push(`${c.name}: ${e.message}`); }
  }
  logger.info('cookie', '导入 Cookie: 成功 ' + results.success + ' 个, 失败 ' + results.failed + ' 个');
  return results;
}

async function clearCookies(domain) {
  const cookies = await getCookies(domain);
  let count = 0;
  for (const c of cookies) {
    try { const url = `${c.secure ? 'https' : 'http'}://${c.domain}${c.path}`; await chrome.cookies.remove({ url, name: c.name }); count++; } catch (e) {}
  }
  logger.info('cookie', '清除 Cookie: ' + domain + ', 已清除 ' + count + ' 个');
  return { removed: count };
}

// ========== Cookie 版本控制 & 来源追踪 ==========

const SYNC_COOKIE_META_KEY = 'sync_cookie_meta';
// 元数据结构：{ "domain:name": { lastValue, origin: "local"|"remote", exportTime: "ISO" } }

async function getCookieMeta() {
  return await getStorage(SYNC_COOKIE_META_KEY, {});
}

async function saveCookieMeta(meta) {
  await setStorage(SYNC_COOKIE_META_KEY, meta);
}

// 智能导入：带版本控制 + 来源追踪
// 用于自动同步（P2P 和服务器模式），防止同步循环覆盖
async function importCookiesSmart(cookieData, fromDeviceId) {
  const results = { success: 0, failed: 0, skipped: 0, errors: [] };
  const meta = await getCookieMeta();
  const dataExportTime = cookieData.exportTime || new Date().toISOString();
  let changed = false;

  for (const c of cookieData.cookies) {
    const metaKey = `${c.domain}:${c.name}`;
    const incomingTime = c._exportTime || dataExportTime;

    // 策略1：值相同 → 跳过（防无效写入）
    try {
      const existing = await chrome.cookies.get({
        url: `${c.secure ? 'https' : 'http'}://${c.domain}${c.path}`,
        name: c.name
      });
      if (existing && existing.value === c.value) {
        results.skipped++;
        continue;
      }
    } catch (e) {}

    // 策略2：检查来源时间戳 → 只导入更新的
    const stored = meta[metaKey];
    if (stored && stored.origin === 'local') {
      // 此 Cookie 是本机生成的，只接受更新时间比本地更新的
      if (incomingTime <= stored.exportTime) {
        results.skipped++;
        continue;
      }
    }

    // 执行导入
    try {
      const details = {
        url: `${c.secure ? 'https' : 'http'}://${c.domain}${c.path}`,
        name: c.name, value: c.value,
        path: c.path || '/', secure: c.secure !== false,
        httpOnly: c.httpOnly === true, sameSite: c.sameSite || 'lax'
      };
      if (!c.hostOnly) details.domain = c.domain;
      await chrome.cookies.set(details);
      results.success++;

      // 标记为远程来源（导入的不会再次被导出）
      meta[metaKey] = { lastValue: c.value, origin: 'remote', exportTime: incomingTime };
      changed = true;
    } catch (e) {
      results.failed++;
      results.errors.push(`${c.name}: ${e.message}`);
    }
  }

  if (changed) await saveCookieMeta(meta);
  return results;
}

// 智能导出：只导出来源为 "local" 的 Cookie（防循环）
async function exportCookiesSmart(domain) {
  const cookies = await getCookies(domain);
  if (cookies.length === 0) return { success: false, message: '未找到该域名的 Cookie', data: null };
  
  const meta = await getCookieMeta();
  const exportTime = new Date().toISOString();
  
  // 只导出被标记为 "local" 或没有标记的 Cookie
  const syncCookies = cookies.filter(c => {
    const metaKey = `${c.domain}:${c.name}`;
    const stored = meta[metaKey];
    if (!stored) return true; // 无记录 = 本地生成
    if (stored.origin === 'local') return true;
    // 远程导入的 Cookie，检查值是否被 OA 动态更新
    if (c.value !== stored.lastValue) {
      // 值变了（页面动态更新），转为 local
      meta[metaKey] = { ...stored, origin: 'local', lastValue: c.value, exportTime };
      return true;
    }
    return false; // 远程导入的且值没变 → 不导出
  });
  
  await saveCookieMeta(meta);
  
  if (syncCookies.length === 0) return { success: false, message: '无可同步的 Cookie（从设备模式或来源追踪过滤）', data: null };
  
  const data = {
    domain, exportTime,
    cookies: syncCookies.map(c => ({
      name: c.name, value: c.value, domain: c.domain, path: c.path,
      secure: c.secure, httpOnly: c.httpOnly, sameSite: c.sameSite,
      hostOnly: c.hostOnly, _exportTime: exportTime
    })),
    quick: syncCookies.map(c => `${c.name}=${c.value}`).join('; ')
  };
  return { success: true, message: `已导出 ${syncCookies.length} 个 Cookie`, data };
}

// 无条件导入（用于手动导入，用户主动操作）
async function importCookiesUnconditional(cookieData) {
  const results = { success: 0, failed: 0, errors: [] };
  for (const c of cookieData.cookies) {
    try {
      const details = {
        url: `${c.secure ? 'https' : 'http'}://${c.domain}${c.path}`,
        name: c.name, value: c.value,
        path: c.path || '/', secure: c.secure !== false,
        httpOnly: c.httpOnly === true, sameSite: c.sameSite || 'lax'
      };
      if (!c.hostOnly) details.domain = c.domain;
      await chrome.cookies.set(details);
      results.success++;
    } catch (e) {
      results.failed++;
      results.errors.push(`${c.name}: ${e.message}`);
    }
  }
  return results;
}

// ========== 加密工具 ==========

async function encryptData(plaintext, password) {
  const encoder = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey('raw', encoder.encode(password), { name: 'PBKDF2' }, false, ['deriveKey']);
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const key = await crypto.subtle.deriveKey({ name: 'PBKDF2', salt, iterations: 100000, hash: 'SHA-256' }, keyMaterial, { name: 'AES-GCM', length: 256 }, false, ['encrypt']);
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const encrypted = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, encoder.encode(plaintext));
  const combined = new Uint8Array(salt.length + iv.length + encrypted.byteLength);
  combined.set(salt, 0); combined.set(iv, salt.length); combined.set(new Uint8Array(encrypted), salt.length + iv.length);
  return btoa(String.fromCharCode(...combined));
}

async function decryptData(ciphertext, password) {
  const combined = Uint8Array.from(atob(ciphertext), c => c.charCodeAt(0));
  const salt = combined.slice(0, 16); const iv = combined.slice(16, 28); const data = combined.slice(28);
  const encoder = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey('raw', encoder.encode(password), { name: 'PBKDF2' }, false, ['deriveKey']);
  const key = await crypto.subtle.deriveKey({ name: 'PBKDF2', salt, iterations: 100000, hash: 'SHA-256' }, keyMaterial, { name: 'AES-GCM', length: 256 }, false, ['decrypt']);
  const decrypted = await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, key, data);
  return new TextDecoder().decode(decrypted);
}

// ========== 同步配置 ==========

async function getSyncConfig() {
  return await getStorage(STORAGE_KEYS.SYNC_CONFIG, { ...SYNC_DEFAULTS });
}

async function saveSyncConfig(config) {
  const existing = await getSyncConfig();
  Object.assign(existing, config);
  await setStorage(STORAGE_KEYS.SYNC_CONFIG, existing);
  return existing;
}

// ========== P2P 连接管理 ==========

let p2pConnections = {};  // { peerId: { connection: RTCPeerConnection, channel: RTCDataChannel, signalInterval } }
let p2pPollTimer = null;
let currentP2PRoomId = '';
let currentP2PPeerId = '';

async function getSignalUrl() {
  const config = await getSyncConfig();
  return config.signalUrl || DEFAULT_SYNC_CONFIG.signalUrl;
}

function generateP2PPeerId() {
  return 'p2p-' + Date.now().toString(36) + '-' + Math.random().toString(36).substring(2, 6);
}

// 创建 P2P 配对房间
async function p2pCreateRoom(deviceName) {
  const peerId = generateP2PPeerId();
  const signalUrl = await getSignalUrl();

  try {
    const resp = await fetch(`${signalUrl}/api/signal/room`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'create', peerId, deviceName: deviceName || peerId })
    });
    const data = await resp.json();
    if (!data.roomId) throw new Error('创建房间失败');

    currentP2PRoomId = data.roomId;
    currentP2PPeerId = peerId;
    await saveSyncConfig({ p2pRoomId: data.roomId, p2pConnected: false });

    // 开始轮询信令消息
    startP2PPolling(signalUrl, data.roomId, peerId);

    return { success: true, roomId: data.roomId, peerId };
  } catch (e) {
    return { success: false, error: e.message };
  }
}

// 加入已有 P2P 配对房间
async function p2pJoinRoom(roomId, deviceName) {
  const peerId = generateP2PPeerId();
  const signalUrl = await getSignalUrl();

  try {
    const resp = await fetch(`${signalUrl}/api/signal/room`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'join', roomId, peerId, deviceName: deviceName || peerId })
    });
    const data = await resp.json();
    if (!data.roomId) throw new Error('加入房间失败');

    currentP2PRoomId = data.roomId;
    currentP2PPeerId = peerId;
    await saveSyncConfig({ p2pRoomId: data.roomId, p2pConnected: false });

    // 如果有已存在的对端，发起 WebRTC 连接
    if (data.peers && data.peers.length > 0) {
      for (const peer of data.peers) {
        initiateP2PConnection(signalUrl, data.roomId, peerId, peer.peerId, deviceName);
      }
    }

    // 开始轮询
    startP2PPolling(signalUrl, data.roomId, peerId);

    return { success: true, roomId: data.roomId, peers: data.peers || [] };
  } catch (e) {
    return { success: false, error: e.message };
  }
}

// 发起 WebRTC 连接
async function initiateP2PConnection(signalUrl, roomId, fromPeer, toPeer, deviceName) {
  const config = { iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] };
  const pc = new RTCPeerConnection(config);
  const channel = pc.createDataChannel('sessionmaster-sync', { ordered: true });

  p2pConnections[toPeer] = { connection: pc, channel, signalUrl, roomId, fromPeer, toPeer };

  channel.onopen = () => {
    console.log('[SessionMaster P2P] 数据通道已打开:', toPeer);
    const connectedAt = new Date().toISOString();
    addSyncHistoryEntry('p2p_connect', '已连接到 ' + (deviceName || toPeer));
    saveSyncConfig({ p2pConnectedAt: connectedAt, p2pConnectedPeerName: deviceName || toPeer });
    channel.onmessage = async (event) => {
      try {
        const msg = JSON.parse(event.data);
        await handleP2PMessage(msg, toPeer);
      } catch (e) { console.warn('[P2P] 消息解析失败:', e); }
    };
    p2pSync(toPeer);
    chrome.runtime.sendMessage({ action: 'p2pStatusUpdate', connected: true, peerId: toPeer, connectedAt, peerName: deviceName || '' }).catch(() => {});
  };

  channel.onclose = () => {
    console.log('[SessionMaster P2P] 数据通道关闭:', toPeer);
    notifyUser('SessionMaster', 'P2P 对端已断开连接');
    chrome.runtime.sendMessage({ action: 'p2pStatusUpdate', connected: false, peerId: toPeer }).catch(() => {});
  };

  pc.onicecandidate = (event) => {
    if (event.candidate) {
      sendSignal(signalUrl, roomId, fromPeer, toPeer, 'ice', event.candidate.toJSON());
    }
  };

  pc.ondatachannel = (event) => {
    const rc = event.channel;
    p2pConnections[toPeer].channel = rc;
    rc.onopen = () => {
      console.log('[SessionMaster P2P] 接收数据通道已打开:', toPeer);
      const connectedAt = new Date().toISOString();
      saveSyncConfig({ p2pConnectedAt: connectedAt, p2pConnectedPeerName: '' });
      rc.onmessage = async (ev) => {
        try { await handleP2PMessage(JSON.parse(ev.data), toPeer); } catch (e) {}
      };
      p2pSync(toPeer);
      chrome.runtime.sendMessage({ action: 'p2pStatusUpdate', connected: true, peerId: toPeer, connectedAt }).catch(() => {});
    };
    rc.onclose = () => { 
      notifyUser('SessionMaster', 'P2P 接收通道已关闭');
      chrome.runtime.sendMessage({ action: 'p2pStatusUpdate', connected: false, peerId: toPeer }).catch(() => {}); 
    };
  };

  try {
    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);
    sendSignal(signalUrl, roomId, fromPeer, toPeer, 'offer', { sdp: offer.sdp, type: offer.type });
  } catch (e) {
    console.error('[P2P] 创建 offer 失败:', e);
  }
}

// 处理信令消息
async function handleSignalMessage(msg) {
  const conn = p2pConnections[msg.from];
  if (!conn) return;

  const pc = conn.connection;
  if (!pc) return;

  try {
    if (msg.type === 'offer' && msg.data) {
      await pc.setRemoteDescription(new RTCSessionDescription(msg.data));
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      sendSignal(conn.signalUrl, conn.roomId, conn.fromPeer, conn.toPeer, 'answer', { sdp: answer.sdp, type: answer.type });
    } else if (msg.type === 'answer' && msg.data) {
      await pc.setRemoteDescription(new RTCSessionDescription(msg.data));
    } else if (msg.type === 'ice' && msg.data) {
      await pc.addIceCandidate(new RTCIceCandidate(msg.data));
    }
  } catch (e) {
    console.warn('[P2P] 信令处理失败:', e.message);
  }
}

// 通过信令服务器发送消息
async function sendSignal(signalUrl, roomId, from, to, type, data) {
  try {
    await fetch(`${signalUrl}/api/signal/message`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ roomId, from, to, type, data })
    });
  } catch (e) {
    console.warn('[P2P] 发送信令失败:', e.message);
  }
}

// 轮询信令消息
function startP2PPolling(signalUrl, roomId, peerId) {
  if (p2pPollTimer) return;

  const poll = async () => {
    try {
      const resp = await fetch(`${signalUrl}/api/signal/poll?room=${roomId}&peer=${peerId}&timeout=25`);
      const data = await resp.json();
      if (data.messages && data.messages.length > 0) {
        for (const msg of data.messages) {
          if (msg.type === 'peer_joined') {
            // 新设备加入，发起连接
            chrome.runtime.sendMessage({ action: 'p2pPeerJoined', peerDeviceName: msg.data.deviceName }).catch(() => {});
            initiateP2PConnection(signalUrl, roomId, peerId, msg.from, msg.data.deviceName);
          } else if (msg.type === 'peer_left') {
            chrome.runtime.sendMessage({ action: 'p2pPeerLeft', peerId: msg.from }).catch(() => {});
            deleteP2PConnection(msg.from);
          } else {
            // 信令消息（offer/answer/ice）
            handleSignalMessage(msg);
          }
        }
      }
    } catch (e) {
      if (!e.message.includes('fetch')) console.warn('[P2P] 轮询错误:', e.message);
    }
    // 继续轮询
    p2pPollTimer = setTimeout(poll, 100);
  };

  poll();
}

function stopP2PPolling() {
  if (p2pPollTimer) { clearTimeout(p2pPollTimer); p2pPollTimer = null; }
}

function deleteP2PConnection(peerId) {
  const conn = p2pConnections[peerId];
  if (conn) {
    try { conn.channel.close(); } catch (e) {}
    try { conn.connection.close(); } catch (e) {}
    delete p2pConnections[peerId];
  }
}

// 断开所有 P2P 连接
async function p2pDisconnect() {
  stopP2PPolling();
  const signalUrl = await getSignalUrl();
  if (currentP2PRoomId && currentP2PPeerId) {
    try {
      await fetch(`${signalUrl}/api/signal/room?room=${currentP2PRoomId}&peer=${currentP2PPeerId}`, { method: 'DELETE' });
    } catch (e) {}
  }
  for (const pid of Object.keys(p2pConnections)) deleteP2PConnection(pid);
  currentP2PRoomId = '';
  currentP2PPeerId = '';
  await saveSyncConfig({ p2pConnected: false, p2pConnectedAt: null, p2pConnectedPeerName: '' });
  notifyUser('SessionMaster', 'P2P 连接已断开');
}

// P2P 同步：发送 Cookie 给对端
async function p2pSync(targetPeer) {
  const config = await getSyncConfig();
  const domain = config.syncedDomains?.[0];
  if (!domain) return;

  // 主从检查：从设备不发送 Cookie
  if (config.masterMode && !config.isMaster) return;

  const exportResult = await exportCookiesSmart(domain);
  if (!exportResult.success) return;

  const channel = p2pConnections[targetPeer]?.channel;
  if (!channel || channel.readyState !== 'open') return;

  try {
    // 用配对码加密
    const pairKey = config.p2pPairKey || 'default';
    const encrypted = await encryptData(JSON.stringify(exportResult.data), pairKey);
    channel.send(JSON.stringify({ action: 'sync', domain, data: encrypted, timestamp: new Date().toISOString() }));
  } catch (e) {
    console.warn('[P2P] 发送同步数据失败:', e);
  }
}

// 处理收到的 P2P 消息
async function handleP2PMessage(msg, fromPeer) {
  if (msg.action === 'sync' && msg.data) {
    const config = await getSyncConfig();
    const pairKey = config.p2pPairKey || 'default';
    try {
      const decryptedStr = await decryptData(msg.data, pairKey);
      const cookieData = JSON.parse(decryptedStr);
      const importResult = await importCookiesSmart(cookieData, fromPeer);
      if (importResult.success > 0) {
        await saveSyncConfig({ lastSyncTime: new Date().toISOString() });
        addSyncHistoryEntry('p2p_sync', '从对端同步了 ' + importResult.success + ' 个 Cookie' + (importResult.skipped > 0 ? '（跳过 ' + importResult.skipped + ' 个未变更）' : ''));
        chrome.runtime.sendMessage({ action: 'p2pSyncComplete', imported: importResult.success, fromPeer }).catch(() => {});
      }
    } catch (e) {
      console.warn('[P2P] 解密/导入失败:', e.message);
    }
  }
}

// ========== 云端同步核心逻辑（服务器模式）==========

async function serverGetSyncConfig() {
  return await getStorage(STORAGE_KEYS.SERVER_SYNC_CONFIG, { ...SERVER_SYNC_DEFAULTS });
}

async function serverSaveSyncConfig(updates) {
  const config = await serverGetSyncConfig();
  Object.assign(config, updates);
  await setStorage(STORAGE_KEYS.SERVER_SYNC_CONFIG, config);
  return config;
}

async function serverRegisterDevice() {
  const config = await serverGetSyncConfig();
  if (!config.serverUrl || !config.pairKey) return { success: false, error: '请先配置服务器地址和配对码' };
  try {
    const resp = await fetch(`${config.serverUrl}/api/pair`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ key: config.pairKey, deviceId: config.deviceId || undefined, deviceName: config.deviceName || `Browser-${Date.now().toString(36)}`, isMaster: config.isMaster !== false })
    });
    const data = await resp.json();
    await serverSaveSyncConfig({ deviceId: data.deviceId, pairKey: data.key });
    return { success: true, data };
  } catch (e) { return { success: false, error: e.message }; }
}

async function serverPerformSync() {
  const config = await serverGetSyncConfig();
  if (!config.enabled || !config.serverUrl || !config.pairKey || !config.deviceId) return { success: false, error: '同步未启用或配置不完整' };

  const results = { upload: null, download: null, imported: false };
  const syncDomain = config.syncedDomains.length > 0 ? config.syncedDomains[0] : '';

  if (syncDomain) {
    // 主从检查：从设备不上传
    if (!config.masterMode || config.isMaster) {
      const exportResult = await exportCookiesSmart(syncDomain);
      if (exportResult.success) {
        try {
          const encrypted = await encryptData(JSON.stringify(exportResult.data), config.pairKey);
          const resp = await fetch(`${config.serverUrl}/api/sync/upload`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ key: config.pairKey, deviceId: config.deviceId, domain: syncDomain, data: encrypted, timestamp: new Date().toISOString() })
          });
          results.upload = await resp.json();
        } catch (e) { results.upload = { error: e.message }; }
      }
    } else {
      results.upload = { skipped: true, message: '从设备模式，跳过上传' };
    }
  }

  try {
    const resp = await fetch(`${config.serverUrl}/api/sync/download?key=${config.pairKey}&deviceId=${config.deviceId}`);
    const downloadData = await resp.json();
    results.download = downloadData;
    // 保存设备状态和冲突警告到配置中
    if (downloadData.warnings) {
      await serverSaveSyncConfig({ masterWarnings: downloadData.warnings, masterDevices: downloadData.devices || [] });
    }
    if (downloadData.success && downloadData.data) {
      for (const [deviceId, cookieEntry] of Object.entries(downloadData.data)) {
        if (cookieEntry.data && cookieEntry.data.length > 0) {
          try {
            const decryptedStr = await decryptData(cookieEntry.data, config.pairKey);
            const cookieData = JSON.parse(decryptedStr);
            const importResult = await importCookiesSmart(cookieData, deviceId);
            if (importResult.success > 0) { results.imported = true; addSyncHistoryEntry('server_sync', '从 ' + deviceId + ' 同步了 ' + importResult.success + ' 个 Cookie' + (importResult.skipped > 0 ? '（跳过 ' + importResult.skipped + ' 个）' : '')); console.log('[SessionMaster] 从 ' + deviceId + ' 同步了 ' + importResult.success + ' 个 Cookie'); }
          } catch (e) { console.warn('[SessionMaster] 解密失败:', e.message); }
        }
      }
    }
  } catch (e) { results.download = { error: e.message }; }

  await serverSaveSyncConfig({ lastSyncTime: new Date().toISOString() });
  return results;
}

async function serverToggleSync(enabled) {
  if (enabled) {
    const config = await serverGetSyncConfig();
    const reg = await serverRegisterDevice();
    if (!reg.success) return reg;
    serverPerformSync().catch(e => console.warn('[SessionMaster] 首次同步失败:', e));
    const intervalMinutes = config.intervalMinutes || 5;
    chrome.alarms.create('sessionSync', { periodInMinutes: intervalMinutes });
    await serverSaveSyncConfig({ enabled: true });
    updateIconState().catch(() => {});
    return { success: true, message: `已启用同步（每 ${intervalMinutes} 分钟）` };
  } else {
    chrome.alarms.clear('sessionSync');
    await serverSaveSyncConfig({ enabled: false });
    updateIconState().catch(() => {});
    return { success: true, message: '已禁用同步' };
  }
}

// ========== Alarm 监听 ==========

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'sessionSync') {
    const config = await serverGetSyncConfig();
    if (config.enabled) {
      const result = await serverPerformSync();
      if (result.imported) console.log('[SessionMaster] ✅ 自动同步完成，已导入新 Cookie');
    }
  }
  if (alarm.name === 'p2pSyncAlarm') {
    // P2P 模式下定时同步给所有已连接的对端
    for (const peerId of Object.keys(p2pConnections)) {
      const conn = p2pConnections[peerId];
      if (conn.channel && conn.channel.readyState === 'open') {
        p2pSync(peerId);
      }
    }
  }
  // 保活定时器
  if (alarm.name.startsWith('heartbeat_')) {
    const id = alarm.name.replace('heartbeat_', '');
    const beats = await getHeartbeats();
    const beat = beats.find(b => b.id === id);
    if (beat && beat.enabled) {
      const result = await performHeartbeat(beat);
      beat.lastHeartbeatTime = new Date().toISOString();
      beat.lastStatus = result.success ? 'ok' : 'fail';
      beat.lastStatusDetail = result.success ? ('HTTP ' + result.status) : result.error;
      await saveHeartbeats(beats);
    }
  }
});

// ========== 保活管理 ==========

const HEARTBEAT_KEY = 'heartbeat_configs';

// 保活配置结构: { id, url, domain, intervalMinutes, enabled }

async function getHeartbeats() { return await getStorage(HEARTBEAT_KEY, []); }

async function saveHeartbeats(beats) {
  await setStorage(HEARTBEAT_KEY, beats);
  // 同步更新 alarms
  const allAlarms = await chrome.alarms.getAll();
  const existing = allAlarms.filter(a => a.name.startsWith('heartbeat_'));
  for (const a of existing) chrome.alarms.clear(a.name);
  for (const beat of beats) {
    if (beat.enabled && beat.url) {
      chrome.alarms.create('heartbeat_' + beat.id, { periodInMinutes: beat.intervalMinutes || 10 });
    }
  }
}

async function addHeartbeat(url, interval, domain, siteName) {
  const beats = await getHeartbeats();
  const id = 'hb_' + Date.now().toString(36) + Math.random().toString(36).substring(2, 4);
  // 如果未传 domain，从 URL 自动提取
  let siteDomain = domain || '';
  if (!siteDomain) {
    try { siteDomain = new URL(url.trim().startsWith('http') ? url.trim() : 'https://' + url.trim()).hostname; } catch {}
  }
  beats.push({ id, url: url.trim(), domain: siteDomain || '', siteName: siteName || '', intervalMinutes: interval || 10, enabled: true, createdAt: new Date().toISOString() });
  await saveHeartbeats(beats);
  updateIconState().catch(() => {});
  return { success: true, heartbeats: beats };
}

async function removeHeartbeat(id) {
  let beats = await getHeartbeats();
  beats = beats.filter(b => b.id !== id);
  await saveHeartbeats(beats);
  chrome.alarms.clear('heartbeat_' + id);
  updateIconState().catch(() => {});
  return { success: true, heartbeats: beats };
}

async function toggleHeartbeat(id, enabled) {
  const beats = await getHeartbeats();
  const beat = beats.find(b => b.id === id);
  if (!beat) return { success: false, error: '未找到该保活配置' };
  beat.enabled = enabled;
  await saveHeartbeats(beats);
  updateIconState().catch(() => {});
  return { success: true, heartbeats: beats };
}

async function performHeartbeat(beat) {
  if (!beat.url) return { success: false, error: 'URL 为空' };
  try {
    const url = beat.domain
      ? (beat.url.startsWith('http') ? beat.url : 'https://' + beat.domain + (beat.url.startsWith('/') ? '' : '/') + beat.url)
      : beat.url;
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 10000);
    const resp = await fetch(url, { method: 'GET', signal: controller.signal, mode: 'no-cors' });
    clearTimeout(timer);
    console.log('[SessionMaster 保活] ✅', url, resp.status);
    return { success: true, status: resp.status };
  } catch (e) {
    console.log('[SessionMaster 保活] ⏸️', beat.url, e.message);
    return { success: false, error: e.message };
  }
}

// ========== 同步历史记录 ==========

const SYNC_HISTORY_KEY = 'sync_history';
const MAX_HISTORY = 50;

async function getSyncHistory() {
  return await getStorage(SYNC_HISTORY_KEY, []);
}

async function addSyncHistoryEntry(type, detail) {
  let history = await getSyncHistory();
  history.unshift({ time: new Date().toISOString(), type, detail });
  if (history.length > MAX_HISTORY) history = history.slice(0, MAX_HISTORY);
  await setStorage(SYNC_HISTORY_KEY, history);
  return history;
}

async function clearSyncHistory() {
  await setStorage(SYNC_HISTORY_KEY, []);
  return [];
}

// ========== 规则库管理（按网站归类 + 远程更新）==========

const USER_RULES_KEY = 'user_blocking_rules';
const RULES_DB_KEY = 'blocking_rules_db';

async function getUserBlockingRules() { return await getStorage(USER_RULES_KEY, []); }

async function addUserBlockingRule(urlPattern) {
  const rules = await getUserBlockingRules();
  if (rules.includes(urlPattern)) return { success: false, message: '该规则已存在' };
  rules.push(urlPattern);
  await setStorage(USER_RULES_KEY, rules);
  await updateDynamicRules(rules);
  logger.info('blocker', '添加自定义规则: ' + urlPattern);
  return { success: true, message: '规则已添加', rules };
}

async function removeUserBlockingRule(urlPattern) {
  let rules = await getUserBlockingRules();
  rules = rules.filter(r => r !== urlPattern);
  await setStorage(USER_RULES_KEY, rules);
  await updateDynamicRules(rules);
  logger.info('blocker', '删除自定义规则: ' + urlPattern);
  return { success: true, message: '规则已删除', rules };
}

async function updateDynamicRules(rules) {
  const newRules = rules.map((pattern, index) => ({ id: 1000 + index, priority: 1, action: { type: 'block' }, condition: { urlFilter: pattern, resourceTypes: ['xmlhttprequest', 'script', 'other', 'sub_frame'] } }));
  const currentRules = await chrome.declarativeNetRequest.getDynamicRules();
  const currentIds = currentRules.map(r => r.id);
  await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: currentIds, addRules: newRules });
}

// 规则库管理
async function getRulesDB() {
  let db = await getStorage(RULES_DB_KEY, null);
  if (!db) {
    // 首次加载：从内置文件读取
    try {
      const resp = await fetch(chrome.runtime.getURL('blocking_rules_db.json'));
      db = await resp.json();
      await setStorage(RULES_DB_KEY, db);
    } catch (e) {
      db = { version: 1, lastUpdated: '', updateUrl: '', sites: [], generic: [] };
    }
  }
  return db;
}

async function saveRulesDB(db) {
  await setStorage(RULES_DB_KEY, db);
  return db;
}

function matchSitesByDomain(db, domain) {
  if (!db || !db.sites || !domain) return [];
  // 去掉端口号（如 oa.zumri.cn:8881 → oa.zumri.cn）
  const cleanDomain = domain.split(':')[0].toLowerCase();
  const matched = [];
  for (const site of db.sites) {
    for (const d of site.domains) {
      const pattern = d.replace(/^(\*\.)?/, '').toLowerCase();
      // 精确匹配: domain === pattern 或 endsWith .pattern
      if (cleanDomain === pattern || cleanDomain.endsWith('.' + pattern)) {
        matched.push(site);
        console.log('[SessionMaster 规则匹配] ✅', site.name, '←', cleanDomain, '(模式:', d + ')');
        break;
      }
      // 通配: 如果 pattern 是 IP 或短域名，尝试用 startsWith
      if (pattern.indexOf('.') < 0 && cleanDomain.startsWith(pattern + '.')) {
        matched.push(site);
        console.log('[SessionMaster 规则匹配] ✅', site.name, '←', cleanDomain, '(通配:', d + ')');
        break;
      }
    }
  }
  if (matched.length === 0) console.log('[SessionMaster 规则匹配] ⏸️', cleanDomain, '未匹配规则');
  return matched;
}

// 获取当前站点的推荐规则（匹配的内置 + 通用规则）
async function getRecommendedRules(domain) {
  const db = await getRulesDB();
  const matched = matchSitesByDomain(db, domain);
  const keywords = [...(db.generic || [])];
  for (const site of matched) {
    for (const kw of (site.keywords || [])) {
      if (!keywords.includes(kw)) keywords.push(kw);
    }
  }
  return { sites: matched, keywords, generic: db.generic || [], keywordLabels: db.keywordLabels || {} };
}

// 远程更新规则库
async function updateRulesDBFromServer() {
  const db = await getRulesDB();
  if (!db.updateUrl) return { success: false, error: '未配置更新地址' };
  try {
    const resp = await fetch(db.updateUrl, { signal: AbortSignal.timeout(15000) });
    const remote = await resp.json();
    if (!remote.sites || !Array.isArray(remote.sites)) return { success: false, error: '远程数据格式无效' };
    await saveRulesDB(remote);
    return { success: true, message: `已更新 ${remote.sites.length} 个站点规则` };
  } catch (e) {
    return { success: false, error: e.message };
  }
}

// 导出规则库为 JSON 字符串
async function exportRulesDB() {
  const db = await getRulesDB();
  return JSON.stringify(db, null, 2);
}

// 导入规则库
async function importRulesDB(jsonStr) {
  try {
    const db = JSON.parse(jsonStr);
    if (!db.sites || !Array.isArray(db.sites)) return { success: false, error: '格式无效：缺少 sites 数组' };
    await saveRulesDB(db);
    return { success: true, message: `已导入 ${db.sites.length} 个站点规则`, sites: db.sites.length };
  } catch (e) {
    return { success: false, error: 'JSON 解析失败: ' + e.message };
  }
}

// ========== 拦截模块配置（主开关 + 自动/手动模式）==========

const BLOCKER_CONFIG_KEY = 'blocker_config';
const DEFAULT_BLOCKER_CONFIG = {
  masterEnabled: true,
  mode: 'auto',           // 'auto' | 'manual'
  siteEnabled: {},        // { siteId: true/false }
  keywordOverrides: {}    // { keyword: true/false }
};

async function getBlockerConfig() {
  return await getStorage(BLOCKER_CONFIG_KEY, DEFAULT_BLOCKER_CONFIG);
}

async function saveBlockerConfig(config) {
  // 合并默认值（保证新加的字段不会丢失）
  const merged = { ...DEFAULT_BLOCKER_CONFIG, ...config };
  // 清理旧的 siteEnabled 条目（规则库中已不存在的站点）
  if (merged.siteEnabled) {
    const db = await getRulesDB();
    const validIds = new Set((db.sites || []).map(s => s.id));
    for (const id of Object.keys(merged.siteEnabled)) {
      if (!validIds.has(id)) delete merged.siteEnabled[id];
    }
  }
  await setStorage(BLOCKER_CONFIG_KEY, merged);
  const changes = [];
  if (config && config.masterEnabled !== undefined) changes.push('主开关=' + config.masterEnabled);
  if (config && config.mode !== undefined) changes.push('模式=' + config.mode);
  if (changes.length > 0) logger.info('blocker', '拦截配置变更: ' + changes.join(', '));
  return merged;
}

// 判断某个域名的拦截是否应该生效
async function isBlockingEnabledForDomain(domain) {
  const config = await getBlockerConfig();
  if (!config.masterEnabled) return false;
  if (!domain) return true;
  const db = await getRulesDB();
  const matched = matchSitesByDomain(db, domain);
  if (matched.length === 0) return false;
  // 自动模式：匹配即生效
  if (config.mode === 'auto') return true;
  // 手动模式：检查站点开关（默认启用）
  for (const site of matched) {
    if (config.siteEnabled[site.id] !== false) return true;
  }
  return false;
}

// 获取当前站点已经启用的有效关键词列表（排除被覆盖关闭的）
async function getEffectiveKeywords(domain) {
  const config = await getBlockerConfig();
  if (!config.masterEnabled) return [];
  const result = await getRecommendedRules(domain);
  if (!result.keywords || result.keywords.length === 0) return [];
  // 自动模式：按 keywordOverrides 过滤
  if (config.mode === 'auto') {
    return result.keywords.filter(kw => config.keywordOverrides[kw] !== false);
  }
  // 手动模式：按 siteEnabled + keywordOverrides 过滤
  const matched = result.sites || [];
  const enabledSites = matched.filter(s => config.siteEnabled[s.id] !== false);
  if (enabledSites.length === 0) return [];
  return result.keywords.filter(kw => config.keywordOverrides[kw] !== false);
}

// ========== API 消息处理 ==========

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  (async () => {
    switch (request.action) {
      // ---- Cookie 管理 ----
      case 'getCookies': sendResponse(await exportCookies(request.domain)); break;
      case 'importCookies': sendResponse(await importCookiesUnconditional(request.data)); break;
      case 'clearCookies': sendResponse(await clearCookies(request.domain)); break;
      case 'getDomainFromUrl': try { sendResponse({ domain: new URL(request.url).hostname }); } catch { sendResponse({ domain: '' }); } break;

      // ---- 拦截规则 ----
      case 'getBlockingRules': sendResponse({ rules: await getUserBlockingRules() }); break;
      case 'addBlockingRule': sendResponse(await addUserBlockingRule(request.urlPattern)); break;
      case 'removeBlockingRule': sendResponse(await removeUserBlockingRule(request.urlPattern)); break;

      // ---- 规则库（按站归类）----
      case 'getRulesDB': sendResponse(await getRulesDB()); break;
      case 'getRecommendedRules': sendResponse(await getRecommendedRules(request.domain)); break;
      case 'updateRulesDBFromServer': sendResponse(await updateRulesDBFromServer()); break;
      case 'exportRulesDB': sendResponse({ data: await exportRulesDB() }); break;
      case 'importRulesDB': sendResponse(await importRulesDB(request.data)); break;

      // ---- 拦截模块配置（主开关 + 自动/手动） ----
      case 'getBlockerConfig': sendResponse(await getBlockerConfig()); break;
      case 'saveBlockerConfig': sendResponse(await saveBlockerConfig(request.config)); break;
      case 'isBlockingEnabled': sendResponse({ enabled: await isBlockingEnabledForDomain(request.domain) }); break;
      case 'getEffectiveKeywords': sendResponse({ keywords: await getEffectiveKeywords(request.domain), keywordLabels: (await getRulesDB()).keywordLabels || {} }); break;

      // ---- 同步配置 ----
      case 'getSyncConfig': sendResponse(await getSyncConfig()); break;
      case 'saveSyncConfig': sendResponse(await saveSyncConfig(request.config)); break;
      case 'saveMasterMode':
        await saveSyncConfig({ masterMode: request.masterMode, isMaster: request.isMaster });
        await serverSaveSyncConfig({ masterMode: request.masterMode, isMaster: request.isMaster });
        updateIconState().catch(() => {});
        sendResponse({ success: true });
        break;

      // ---- P2P 模式 ----
      case 'p2pCreateRoom':
        sendResponse(await p2pCreateRoom(request.deviceName));
        break;
      case 'p2pJoinRoom':
        sendResponse(await p2pJoinRoom(request.roomId, request.deviceName));
        break;
      case 'p2pDisconnect':
        await p2pDisconnect();
        addSyncHistoryEntry('p2p_disconnect', '已断开 P2P 连接');
        sendResponse({ success: true });
        break;
      case 'p2pManualSync':
        for (const peerId of Object.keys(p2pConnections)) {
          if (p2pConnections[peerId].channel?.readyState === 'open') p2pSync(peerId);
        }
        addSyncHistoryEntry('p2p_sync', '已手动触发 P2P 同步');
        sendResponse({ success: true });
        break;
      case 'p2pToggleSync':
        if (request.enabled) {
          await saveSyncConfig({ enabled: true });
          chrome.alarms.create('p2pSyncAlarm', { periodInMinutes: request.intervalMinutes || 5 });
          addSyncHistoryEntry('p2p_enable', '已启用 P2P 自动同步（每 ' + (request.intervalMinutes || 5) + ' 分钟）');
          updateIconState().catch(() => {});
          sendResponse({ success: true, message: '已启用 P2P 同步' });
        } else {
          chrome.alarms.clear('p2pSyncAlarm');
          await saveSyncConfig({ enabled: false });
          addSyncHistoryEntry('p2p_disable', '已禁用 P2P 自动同步');
          updateIconState().catch(() => {});
          sendResponse({ success: true, message: '已禁用 P2P 同步' });
        }
        break;

      // ---- 服务器模式 ----
      case 'serverGetSyncConfig': sendResponse(await serverGetSyncConfig()); break;
      case 'serverSaveSyncConfig': sendResponse(await serverSaveSyncConfig(request.config)); break;
      case 'serverToggleSync': sendResponse(await serverToggleSync(request.enabled)); break;
      case 'serverManualSync':
        sendResponse(await serverPerformSync());
        addSyncHistoryEntry('server_sync', '已手动触发服务器同步');
        break;
      case 'serverRegisterDevice': sendResponse(await serverRegisterDevice()); break;
      case 'serverGetPairStatus':
        const sConfig = await serverGetSyncConfig();
        if (!sConfig.serverUrl || !sConfig.pairKey) { sendResponse({ success: false, error: '未配置' }); break; }
        try {
          const resp = await fetch(`${sConfig.serverUrl}/api/pair/status?key=${sConfig.pairKey}`);
          sendResponse(await resp.json());
        } catch (e) { sendResponse({ success: false, error: e.message }); }
        break;

      // ---- 获取/保存升级检测配置 ----
      case 'getUpdateConfig':
        sendResponse(await getStorage(STORAGE_KEYS.UPDATE_CONFIG, { url: UPDATE.DEFAULT_URL, enabled: UPDATE.ENABLED }));
        break;
      case 'setUpdateConfig':
        await setStorage(STORAGE_KEYS.UPDATE_CONFIG, request.config);
        sendResponse({ success: true });
        break;
      case 'getAppConfig':
        sendResponse(APP_CONFIG);
        break;

      // ---- 保活 ----
      case 'getHeartbeats': sendResponse({ heartbeats: await getHeartbeats() }); break;
      case 'addHeartbeat':
        sendResponse(await addHeartbeat(request.url, request.interval, request.domain, request.siteName));
        break;
      case 'removeHeartbeat':
        sendResponse(await removeHeartbeat(request.id));
        break;
      case 'toggleHeartbeat':
        sendResponse(await toggleHeartbeat(request.id, request.enabled));
        break;

      // ---- 同步历史 ----
      case 'getSyncHistory': sendResponse({ history: await getSyncHistory() }); break;
      case 'clearSyncHistory': sendResponse({ history: await clearSyncHistory() }); break;

      // ---- 日志 ---- 
      case 'getLogs': sendResponse({ logs: await getLogs() }); break;
      case 'exportLogs': sendResponse({ text: await exportLogs() }); break;
      case 'clearLogs': await clearLogs(); sendResponse({ success: true }); break;

      // ---- 设备身份 ----
      case 'getDeviceIdentity':
        const devIdent = await getDeviceIdentity();
        const devName = await getDeviceDisplayName();
        const devDetails = await collectDeviceDetails();
        const netInfo = await collectNetworkInfo();
        sendResponse({
          id: devIdent.id,
          createdAt: devIdent.createdAt,
          deviceName: devName,
          os: devDetails.os,
          arch: devDetails.arch,
          browser: devDetails.browser,
          browserVer: devDetails.browserVer,
          language: devDetails.language,
          platform: devDetails.platform,
          cpuCores: devDetails.cpuCores,
          deviceMemory: devDetails.deviceMemory,
          uaShort: devDetails.uaShort,
          network: netInfo
        });
        break;
      case 'resetDeviceIdentity': sendResponse(await resetDeviceIdentity()); break;
      case 'addSyncHistoryEntry':
        sendResponse({ history: await addSyncHistoryEntry(request.type, request.detail) });
        break;

      // ---- 网络信息 ----
      case 'getNetworkInfo':
        try {
          if (chrome.system && chrome.system.network && typeof chrome.system.network.getNetworkInterfaces === 'function') {
            const ifaces = await chrome.system.network.getNetworkInterfaces();
            const ipv4 = (ifaces || []).filter(i => i && i.address && i.address.includes('.')).map(i => ({ name: i.name || '', address: i.address }));
            const ipv6 = (ifaces || []).filter(i => i && i.address && i.address.includes(':')).map(i => ({ name: i.name || '', address: i.address }));
            sendResponse({ success: true, ipv4, ipv6 });
          } else {
            sendResponse({ success: false, error: 'API 不可用' });
          }
        } catch (e) { sendResponse({ success: false, error: e.message }); }
        break;

      default:
        sendResponse({ error: '未知操作' });
    }
  })();
  return true;
});

function notifyUser(title, message) {
  try {
    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'icons/icon128.svg',
      title: title,
      message: message,
      priority: 1
    });
  } catch (e) {}
}

// ========== 安装时初始化 ==========

chrome.runtime.onInstalled.addListener(async () => {
  // 首次安装时创建设备身份
  const identity = await getDeviceIdentity();
  const deviceName = await getDeviceDisplayName();
  const nameTag = deviceName ? ' (' + deviceName + ')' : '';
  logger.info('general', '插件已安装 — 设备: ' + identity.id + nameTag);

  const rules = await getUserBlockingRules();
  if (rules.length > 0) await updateDynamicRules(rules);

  // 恢复之前的同步状态
  const config = await getSyncConfig();
  if (config.enabled) {
    if (config.mode === 'p2p' && config.p2pRoomId) {
      chrome.alarms.create('p2pSyncAlarm', { periodInMinutes: config.intervalMinutes || 5 });
      console.log('[SessionMaster] 已恢复 P2P 同步定时器');
    } else if (config.mode === 'server' && config.pairKey) {
      chrome.alarms.create('sessionSync', { periodInMinutes: config.intervalMinutes || 5 });
      console.log('[SessionMaster] 已恢复服务器同步定时器');
    }
  }

  console.log('[SessionMaster] 插件已安装');

  // 刷新图标角标
  updateIconState().catch(() => {});

  // SW 重启后重置 P2P 连接状态（WebRTC 连接只存在内存中，重启后丢失）
  getSyncConfig().then(cfg => {
    if (cfg.p2pConnected) {
      saveSyncConfig({ p2pConnected: false, p2pConnectedAt: null, p2pConnectedPeerName: '' });
    }
  });

  // 恢复保活定时器
  getHeartbeats().then(beats => {
    for (const beat of beats) {
      if (beat.enabled && beat.url) {
        chrome.alarms.create('heartbeat_' + beat.id, { periodInMinutes: beat.intervalMinutes || 10 });
      }
    }
  });
});
